# php-omp
A simple, incomplete php-implementation of OpenVAS'  omp5 implementation. This can be used to connect to an instance of OpenVAS manager.



Author Dustin Demuth 2014-2015

Westfälische Wilhelms-Universität Münster

Zentrum für Informationsverarbeitung - CERT

www.uni-muenster.de
